<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


	<?php echo e($data->title); ?>

	

	<iframe height="400"  width="400" src="/cover/<?php echo e($data->cover); ?>"></iframe>

</body>
</html><?php /**PATH H:\Laravel\work\Laravel-CRUD-With-Multiple-Image-Upload-master\Laravel-CRUD-With-Multiple-Image-Upload-master\resources\views/viewfile.blade.php ENDPATH**/ ?>