<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


	{{$data->title}}
	

	<iframe height="400"  width="400" src="/cover/{{$data->cover}}"></iframe>

</body>
</html>